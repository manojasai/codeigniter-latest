<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->library(array('session'));
		$this->load->helper(array('url','form','date'));
		$this->load->database();
		$this->load->model('welcome_model');
	}

	public function index()
	{
		$this->load->view('login');
	}
	public function login_submit()
	{
	$username=$this->input->post('username');
	$password=$this->input->post('password');
	$result=$this->welcome_model->login_submit($username,$password);
	if(count($result)>0){
	$session_data=array(
	'user_id'=>$result[0]->id,
	'username'=>$result[0]->username,
	'logged_in'=>TRUE
	);
	$this->session->set_userdata($session_data);
	redirect('welcome/product');
	
	}
	else{
	$this->load->view('login');
	}
		
	}
	public function register_submit()
	{
	$username=$this->input->post('username');
	$email=$this->input->post('username');
	$password=$this->input->post('password');
	$cpassword=$this->input->post('cpassword');
	if($password==$cpassword){
		redirect('welcome/login');
		}
		else{
		$this->load->view('login');
		}
	$result=$this->welcome_model->register_submit($username,$email,$password,$cpassword);
}
public function product()
	{
	$data['product']=$this->welcome_model->product_details();
		$this->load->view('product',$data);
	}
	public function addproduct()
	{
	$this->load->view('add');
	}
	public function add_product()
	{
	$name=$this->input->post('name');
	$description=$this->input->post('description');
	$price=$this->input->post('price');
	//$image=$this->input->post('image');
	$result=$this->welcome_model->add_product($name,$description,$price);
	redirect('welcome/product');
	}
	public function editproduct($id)
	{
	$data['product']=$this->welcome_model->get_product_details($id);
	$this->load->view('edit',$data);
	
	}
	public function edit_product()
	{
	$name=$this->input->post('name');
	$description=$this->input->post('description');
	$price=$this->input->post('price');
	$id=$this->input->post('id');
	
	//$image=$this->input->post('image');
	$result=$this->welcome_model->edit_product($name,$description,$price,$id);
	redirect('welcome/product');
	}
	

}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome_model extends CI_Model{
	public function login_submit($username,$password){
		$this->db->select('id,username');
		$this->db->from('login');
		$this->db->where('username',$username);
		$this->db->where('password',md5($password));
		$this->db->where('password',md5($password));
		$query=$this->db->get();
		$result=$query->result();
		return $result;
		}
		public function register_submit($username,$email,$password,$cpassword){
		$data=array(
		'username'=>$username,
		'email'=>$email,
		'password'=>md5($password),
		'cpassword'=>md5($cpassword),
		);
		
		$this->db->insert('login',$data);
		}
		public function product_details(){
		$this->db->select('*');
		$this->db->from('product');
		$query=$this->db->get();
		$result=$query->result();
		return $result;
		}
		public function add_product($name,$description,$price,$image){
		$data=array(
		'name'=>$name,
		'description'=>$description,
		'price'=>$price,
		
		);
		
		$this->db->insert('product',$data);
		}
		public function get_product_details($id){
		$this->db->select('*');
		$this->db->from('product');
		$this->db->where('id',$id);
		$query=$this->db->get();
		$result=$query->result();
		return $result;
		}
		public function edit_product($name,$description,$price,$id){
		$data=array(
		'name'=>$name,
		'description'=>$description,
		'price'=>$price,
		
		);
		$this->db->where('id',$id);
		$this->db->update('product',$data);
		}
		
		
}
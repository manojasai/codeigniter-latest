<html>
<form action="<?php echo base_url();?>index.php/welcome/add_product" method="post" enctype="multipart/form-data">
name:<input type="text" name="name" >
description:<input type="text" name="description" >
price:<input type="text" name="price" >
image:<input type="file" name="image" >
<input type="submit" name="submit">
</form>

</html>
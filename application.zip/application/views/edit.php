<html>
<form action="<?php echo base_url();?>index.php/welcome/edit_product" method="post" enctype="multipart/form-data">
name:<input type="text" name="name" value="<?php echo $product[0]->name;?>" >
description:<input type="text" name="description" value="<?php echo $product[0]->description;?>" >
price:<input type="text" name="price" value="<?php echo $product[0]->price;?>" >
image:<input type="file" name="image" >
<input type="hidden" name="id" value="<?php echo $product[0]->id;?>" >

<input type="submit" name="submit" value="update">
</form>

</html>
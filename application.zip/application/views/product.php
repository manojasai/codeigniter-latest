<html>
<head>
<a href="<?php echo base_url();?>index.php/welcome/addproduct">ADD PRODUCT</a>
<table border="1">
<tr>
<th>sl.no</th>
<th>name</th>
<th>description</th>
<th>image</th>
<th>price</th>
<th>action</th>
</tr>
<tbody>
<?php
$j=1;for($i=0;$i<count($product);$i++){?>
<tr>
<td><?php echo $j;?></td>
<td><?php echo $product[$i]->name;?></td>
<td><?php echo $product[$i]->description;?></td>
<td><?php echo $product[$i]->image;?></td>
<td><?php echo $product[$i]->price;?></td>
<td><a href="<?php echo base_url();?>index.php/welcome/editproduct/<?php echo $product[$i]->id;?>">edit</a></td>
<?php $j++;}?>
</tr>
</tbody>
</table>
</head>
</html>

